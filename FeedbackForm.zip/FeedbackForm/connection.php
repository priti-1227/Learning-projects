<?php

// Server name must be localhost
$servername = "localhost";

// In my case, user name will be root
$username = "root";

// Password is empty
$password = "";
 
$dbname = "priti";

// Creating a connection
$conn = new mysqli($servername,
			$username, $password);

            // $sql="INSERT INTO `form`(`firstname`, `lastname`, `email`, `subject`, `message`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]')";

// Check connection
if ($conn->connect_error) {
	die("Connection failure: "
		. $conn->connect_error);
}

?>
