const bigStar = document.querySelector('.big-star i');
const stars = document.querySelectorAll('.star');
const ratingText = document.querySelector('.selected-rating');
const feedbackmessage = document.querySelector('.feedback-message');
const btn = document.querySelector('.rating button');