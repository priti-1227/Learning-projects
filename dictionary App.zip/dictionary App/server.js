const express = require('express')
const app = express()
const path = require("path")
const axios = require("axios")
const port = 3000

app.get('/', (req, res) => {
  console.log(path.join(__dirname, 'public'))
  return res.sendFile('public/index.html' , {root : __dirname});
})


app.get('/searchword', (req, res) => {
  // res.send('Hello World!')
  console.log(req.params)
 

var options = {
  method: 'GET',
  url: 'https://urban-dictionary7.p.rapidapi.com/v0/define',
  params: {term: 'ridiculous'},
  headers: {
    'X-RapidAPI-Key': '0d460f3d63mshb19083ade718be7p1b95f2jsn63e4dc7a245e',
    'X-RapidAPI-Host': 'urban-dictionary7.p.rapidapi.com'
  }
};

axios.request(options).then(function (response) {
  console.log(response.data);
}).catch(function (error) {
  console.error(error);
});
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port} . https://localhost:3000`)
})