// Function to handle the drag start event
function drag(event) {
    event.dataTransfer.setData("text/plain", event.target.id);
    event.target.style.opacity = "0.4";
  }
  
  // Function to allow dropping on the right container
  function allowDrop(event) {
    event.preventDefault();
  }
  
  // Function to handle the drop event
  function drop(event) {
    event.preventDefault();
    var data = event.dataTransfer.getData("text/plain");
    var draggableElement = document.getElementById(data);
    var dropzone = event.target;
  
    dropzone.appendChild(draggableElement);
    draggableElement.style.opacity = "1";
    showSuccessMessage();
  }
  
  // Function to show a success message when an item is dropped
  function showSuccessMessage() {
    var successMessage = document.createElement("p");
    successMessage.className = "success-message";
    successMessage.textContent = "Item dropped successfully!";
    document.body.appendChild(successMessage);
    setTimeout(function() {
      successMessage.parentNode.removeChild(successMessage);
    }, 2000);
  }
  
  // Function to reset the containers
  function resetContainers() {
    var leftContainer = document.querySelector(".left-container");
    var rightContainer = document.querySelector(".right-container");
    rightContainer.innerHTML = "<h3>Container 2</h3>";
    var items = leftContainer.querySelectorAll(".item");
    items.forEach(function(item) {
      leftContainer.appendChild(item);
    });
  }
  
  // Add drag event listeners to the draggable items
  var items = document.querySelectorAll(".item");
  items.forEach(function(item) {
    item.addEventListener("dragstart", drag);
  });
  